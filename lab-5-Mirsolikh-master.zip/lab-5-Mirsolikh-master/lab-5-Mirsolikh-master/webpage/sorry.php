<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<title>Buy Your Way to a Better Education!</title>
		<link href="http://www.cs.washington.edu/education/courses/cse190m/09sp/labs/4-buyagrade/buyagrade.css" type="text/css" rel="stylesheet" />
	<script type="text/javascript" src="https://gc.kis.v2.scr.kaspersky-labs.com/FD126C42-EBFA-4E12-B309-BB3FDD723AC1/main.js?attr=-EHHtPP0nKiWUB8wPmCSXJnZUtJNM1GMH5dOm-bi6_ImwXcreCxrh0YiHuGd7P_JUEKbX5IoJG6OD91cQoHgJJnSDRZDWNprs09hvCXjC1Q21Xtz6sMRiYzvK8Ku8FRm" charset="UTF-8"></script></head>

	<body>
		<div>
	<h1>Sorry!!!</h1>
	<p> You didnt fill the form correctly.
		<a href="http://localhost/lab-5-OverLordN7/webpage/buyagrade.php">Try again.</a>
	</p>
	
</div>

	</body>
</html>  